const IPFS = require('ipfs-api');
const OrbitDB = require('orbit-db');

const ipfsOptions = { host: 'localhost', port: '5001' };

async function main() {
  // Create IPFS instance
  const ipfs = new IPFS(ipfsOptions);
  console.log('Connected to IPFS');

  const orbitdb = await OrbitDB.createInstance(ipfs)
  console.log('OrbitDB instance created.')
}

main();
